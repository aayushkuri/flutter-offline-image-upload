
import 'dart:typed_data';
import 'package:http/http.dart' as http;

Future<void> uploadImage(Uint8List imageBytes) async {
  final uri = Uri.parse('https://httpbin.org/post');
  final request = http.MultipartRequest('POST', uri)
    ..files.add(http.MultipartFile.fromBytes(
      'file',
      imageBytes,
      filename: 'upload.jpg',
    ));

  final response = await request.send();
  if (response.statusCode != 200) {
    throw Exception("Upload failed with status: ${response.statusCode}");
  }
}
