
import 'dart:typed_data';
import 'package:flutter/material.dart';

class UploadProvider extends ChangeNotifier {
  Uint8List? _pendingImage;
  String _status = "Idle";

  Uint8List? get pendingImage => _pendingImage;
  String get status => _status;

  void saveImageInMemory(Uint8List image) {
    _pendingImage = image;
    notifyListeners();
  }

  void clearImage() {
    _pendingImage = null;
    notifyListeners();
  }

  void setStatus(String newStatus) {
    _status = newStatus;
    notifyListeners();
  }
}
